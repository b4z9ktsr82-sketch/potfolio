/* ==========================================================================
   SITE CONFIGURATION
   Edit these values — they are used by the contact form (contact.js).
   ========================================================================== */
window.SITE_CONFIG = {
  // PLACEHOLDER: your real email address. Used for the mailto fallback.
  email: "your.email@example.com",

  // Form service endpoint. Leave empty ("") until you connect a service.
  // Examples (you create the form in their dashboard and paste the URL here):
  //   Formspree:  "https://formspree.io/f/xxxxxxx"
  //   Getform:    "https://getform.io/f/xxxxxxx"
  //   Your own PHP/backend script: "send-mail.php"
  // The endpoint must accept a JSON POST and return a 2xx status on success.
  formEndpoint: ""
};
