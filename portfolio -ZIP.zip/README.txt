==========================================================================
 PERSONAL PORTFOLIO — README
 Static website: HTML5 + CSS3 + vanilla JavaScript (+ Three.js for the 3D hero)
 No build step, no Node.js, no server-side code. Upload and it works.
==========================================================================


--------------------------------------------------------------------------
1. PROJECT STRUCTURE
--------------------------------------------------------------------------

portfolio/
  index.html              Home (3D hero, about, featured project, skills, experience, CTA)
  about.html              About me (bio, journey, interests & goals, technical interests)
  projects.html           All projects (generated from js/projects.js)
  project-details.html    Case study page (project-details.html?id=PROJECT-ID)
  skills.html             Skills, areas of expertise, tools
  experience.html         Work experience, education, certifications, achievements
  services.html           Services and work process
  resume.html             Online resume + "Download resume" (PDF) + Print
  contact.html            Contact form with validation, email, social links
  404.html                Custom "page not found" page
  robots.txt              Search-engine rules
  sitemap.xml             List of pages for search engines
  favicon.ico             Browser tab icon
  .htaccess               Apache settings: custom 404, compression, caching
                          (hidden file — make sure it gets uploaded too)

  css/
    style.css             Design tokens (colors, fonts) + all components
    animations.css        Keyframes, scroll reveal, page transitions, reduced motion
    responsive.css        Tablet / mobile layouts, mobile menu, print styles

  js/
    config.js             Your email + contact-form service URL     <-- edit
    projects.js           Your project data                         <-- edit
    navigation.js         Menu, active page, mobile menu, page transitions
    animations.js         Scroll reveal, 3D tilt, parallax, cursor glow, etc.
    hero3d.js             Three.js scene on the home page
    contact.js            Contact form validation and sending
    main.js               Small helpers (footer year, copy button, print)
    vendor/three.min.js   Three.js r128 (MIT licence), stored locally — no CDN needed

  assets/
    images/
      profile-placeholder.jpg       <-- replace with your photo
      project-placeholder.jpg       <-- replace with your project screenshot
      screenshot-placeholder-1.jpg  <-- replace (case-study screenshots)
      screenshot-placeholder-2.jpg  <-- replace
      og-image.jpg                  <-- image shown when the site is shared on social media
      favicon.png                   <-- 180x180 icon (Apple devices)
    icons/
      favicon.svg                   <-- vector monogram favicon
    documents/
      resume.pdf                    <-- PLACEHOLDER PDF: replace with your real resume


--------------------------------------------------------------------------
2. HOW PLACEHOLDERS WORK
--------------------------------------------------------------------------

Everything you need to personalise is written in [square brackets], for
example [Your Name], [Your Professional Title], [City, Country].

Fastest way to replace them across ALL pages at once:
  1. Open the "portfolio" folder in a code editor (e.g. VS Code — free).
  2. Press Ctrl+Shift+H (Find & Replace in files).
  3. Replace these, one by one:
       [Your Name]                   -> your full name
       [Your Professional Title]     -> e.g. Front-End Developer
       [City, Country]               -> your location (or remove it)
       your.email@example.com        -> your real email address
       your-username                 -> your GitHub / LinkedIn / X username
       https://www.example.com/      -> your real domain (SEO tags, sitemap, robots)
  4. Then search for "[" to find the remaining placeholders (paragraphs,
     experience entries, etc.) and write your own text.

Search for "EXAMPLE CONTENT" to find lists that contain example values
(skills, tools, technical interests). These are examples only — replace them
with your real skills. Delete any card/section you don't need yet
(e.g. Certifications or Achievements).


--------------------------------------------------------------------------
3. REPLACE THE PROFILE PHOTO
--------------------------------------------------------------------------

1. Prepare a portrait-orientation photo (about 800 x 1000 px), saved as JPG,
   ideally under 250 KB (use https://squoosh.app to compress it).
2. Name it  profile-placeholder.jpg  and overwrite the file in assets/images/.
   OR give it a new name (e.g. me.jpg) and replace
   "assets/images/profile-placeholder.jpg" in index.html and about.html.
3. If your face is cropped, change  object-position: center 25%;  in
   css/style.css (.portrait__img). Lower % = show more of the top.


--------------------------------------------------------------------------
4. NAME, LOGO AND FAVICON
--------------------------------------------------------------------------

The logo is an HTML/CSS monogram:
   <span class="logo__mark">YN</span>  ->  replace YN with your initials
   your<span class="logo__accent">_</span>name  ->  e.g. john<span ...>_</span>doe
It appears in the header and the footer of every page (Find & Replace "YN"
and "your<span" to change them all).

To use an image logo instead, put it in assets/images/ and replace both
<span>s inside <a class="logo"> with:
   <img class="logo__img" src="assets/images/logo.png" alt="" width="40" height="40">

Favicon: edit the letters in assets/icons/favicon.svg (open it in a text
editor), and replace favicon.ico / assets/images/favicon.png with your own
(https://realfavicongenerator.net can create them from one image).


--------------------------------------------------------------------------
5. PROJECTS — EDIT AND ADD MORE
--------------------------------------------------------------------------

All project content lives in  js/projects.js.

Edit:  replace the [bracketed] text in the first project.
Links: set liveUrl and sourceUrl, e.g.
          liveUrl: "https://my-project.example.com",
          sourceUrl: "https://github.com/me/my-project"
       Leave them as "" and the buttons show "— soon" (disabled) instead of
       linking nowhere.
Images: put screenshots in assets/images/ and update "cover" and "screenshots".

Add a project:
  1. Copy the whole { ... } block of the first project.
  2. Paste it after it, with a comma between the two blocks:  }, {
  3. Give it a unique id, e.g. id: "weather-app"
  4. Its page is automatically:  project-details.html?id=weather-app
  - featured: true  -> also shown on the Home page.
  - Category filter buttons appear automatically once projects have
    different categories.
  - The "More projects are on the way" card can be removed in the
    soonCard() part of projects.js (search for soonCard() in renderGrid).


--------------------------------------------------------------------------
6. RESUME PDF
--------------------------------------------------------------------------

assets/documents/resume.pdf is a PLACEHOLDER that says "replace me".
Export your resume as PDF, name it  resume.pdf  and overwrite that file.
The "Download resume" button on resume.html will then download your file
(the downloaded file name is set by download="Your-Name-Resume.pdf" in
resume.html — change it to your name).
Also fill in the online resume in resume.html (the light "paper" section).


--------------------------------------------------------------------------
7. CONTACT FORM
--------------------------------------------------------------------------

The form validates all fields in the browser (name, email, subject, message
min. 20 characters) and shows clear errors.

A static website cannot send email by itself. So, out of the box:
  - NOTHING is sent. After a valid submit the visitor is told the form is not
    connected and is offered an "Open email app" button (mailto:) that opens
    their own email program with the message already filled in.
  - mailto limitations: it only works if the visitor has an email app set up
    (Outlook, Mail, Gmail app…). On some computers nothing happens, and
    very long messages may be cut off. That's why your email address is also
    shown on the page with a "Copy" button.

To make the form really send messages (recommended):
  1. Create a free form at a service such as Formspree (formspree.io),
     Getform or Basin. Copy the form endpoint URL they give you.
  2. Open js/config.js and paste it:
        formEndpoint: "https://formspree.io/f/abcdwxyz"
  3. Also set  email: "you@yourdomain.com"  there.
  The form then POSTs JSON (name, email, subject, message) and shows
  "message sent" ONLY when the service confirms success; otherwise it shows
  an error with an "Email instead" button.
  (You can also point formEndpoint to your own PHP script on your hosting.)


--------------------------------------------------------------------------
8. COLORS AND FONTS
--------------------------------------------------------------------------

Open css/style.css — section "1. DESIGN TOKENS" at the top:

  --c-navy:   #1C2644   dark navy (dark surfaces, text on light)
  --c-blue:   #0A387D   primary blue (buttons, key elements)
  --c-sky:    #3D87CB   light blue (highlights, hover, animated accents)
  --c-mist:   #DAE4EE   light gray (light text, borders, resume paper)
  --c-orange: #E77723   used ONLY for the blinking terminal cursor
  --bg:       #0B1122   page background (a deeper navy derived from the palette)

Change a value once and it updates everywhere. The 3D scene colors are at
the top of js/hero3d.js (COLORS).

Fonts (Google Fonts): Space Grotesk (headings/body) + IBM Plex Mono (labels).
They are loaded in the <head> of every page; change --f-display / --f-body /
--f-mono in style.css if you switch fonts.


--------------------------------------------------------------------------
9. ANIMATIONS, 3D AND ACCESSIBILITY
--------------------------------------------------------------------------

- Home hero: Three.js wireframe "core" behind your photo, orbiting shapes and
  particles, reacting to mouse and scroll. It pauses when scrolled out of view
  or when the tab is hidden, and uses fewer particles on phones / low-power
  devices.
- If WebGL is not available, a CSS 3D fallback is shown automatically.
- Inner pages use light CSS 3D shapes (no Three.js loaded = faster).
- Scroll reveals, 3D tilt cards, magnetic buttons, cursor-following grid
  glow, page-leave transition, scroll progress bar, timeline fill.
- "Reduce motion" setting of the operating system is respected: animations,
  transitions and the 3D loop are switched off.
- Tilt/magnetic effects are disabled on touch devices.
- Content never depends on animations: without JavaScript all content is
  still visible (except the project list, which shows a notice).


--------------------------------------------------------------------------
10. HEADER / FOOTER ON EVERY PAGE
--------------------------------------------------------------------------

The header and footer are plain HTML in each page (so they work without
JavaScript and are good for SEO). If you change a menu item, change it in
all 10 HTML files — Find & Replace in files (Ctrl+Shift+H) makes this quick.
The current page is highlighted automatically.


--------------------------------------------------------------------------
11. DEPLOY WITH cPANEL (File Manager)
--------------------------------------------------------------------------

1. Log in to cPanel -> open "File Manager".
2. Open the  public_html  folder (your domain's root folder).
   (Settings, top-right -> tick "Show Hidden Files" so you can see .htaccess.)
3. Click "Upload" and upload  portfolio.zip.
4. Back in File Manager, right-click portfolio.zip -> "Extract" into public_html.
5. IMPORTANT: the files must sit DIRECTLY in public_html, e.g.
       public_html/index.html
       public_html/css/style.css
   If they were extracted into public_html/portfolio/, open that folder,
   select all (including .htaccess), "Move" them to /public_html, then
   delete the empty portfolio folder and the zip.
6. Visit https://yourdomain.com — done.


--------------------------------------------------------------------------
12. DEPLOY WITH FTP (FileZilla)
--------------------------------------------------------------------------

1. Get your FTP host, username and password from your hosting panel.
2. Open FileZilla -> enter Host, Username, Password, Port 21 -> Quickconnect.
3. Right panel (server): open  public_html.
4. Left panel (your computer): open the "portfolio" folder.
5. Select EVERYTHING inside it (Server -> "Force showing hidden files" so
   .htaccess is included) and drag it to public_html.
6. Wait until the transfer queue is empty and "Failed transfers" is 0.


--------------------------------------------------------------------------
13. TEST AFTER UPLOADING
--------------------------------------------------------------------------

[ ] Open https://yourdomain.com — the home page loads with styles and 3D.
[ ] Click every menu item; the current page is highlighted.
[ ] Phone test: open the site on your phone, open/close the menu.
[ ] Open a project card -> the case study page loads.
[ ] Click "Download resume" -> your PDF downloads.
[ ] Contact form: submit empty (errors shown) and valid (sent / mailto).
    If you configured a form service, send yourself a test message.
[ ] Visit https://yourdomain.com/this-does-not-exist -> custom 404 page.
[ ] Open https://yourdomain.com/robots.txt and /sitemap.xml.
[ ] Browser console (F12 -> Console) shows no red errors.
[ ] Share the link in a chat app to check the preview image (og-image.jpg).
[ ] Optional: run PageSpeed Insights (pagespeed.web.dev) on your URL.
[ ] Submit sitemap.xml in Google Search Console.

Hard refresh (Ctrl+F5) if you don't see your latest changes — browsers cache
CSS and JS.


--------------------------------------------------------------------------
14. NOTES
--------------------------------------------------------------------------

- 404 page: it uses <base href="/">, so it works for missing URLs at any
  depth when the site is in the domain root (public_html). If you install the
  site in a sub-folder (e.g. yourdomain.com/portfolio/), change it to
  <base href="/portfolio/"> and update ErrorDocument in .htaccess to
  /portfolio/404.html. Opening 404.html directly from your computer
  (double-click) shows it unstyled — that's expected; it works on the server.
- Previewing locally: double-clicking index.html works. For the most accurate
  preview, use VS Code's "Live Server" extension.
- No tracking, cookies or analytics are included.
